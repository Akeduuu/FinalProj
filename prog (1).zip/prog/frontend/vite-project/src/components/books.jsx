import React, { useState, useEffect } from 'react';
import axios from 'axios';
import RegisterForm from './RegisterForm';
import LoginForm from './LoginForm';
import '../css/Books.css';

function App() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [city, setCity] = useState('');
  const [year, setYear] = useState('');
  const [category, setCategory] = useState('Transport');
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]); // Состояние для отфильтрованных книг
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [currentBook, setCurrentBook] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const categories = ['Transport', 'Technics', 'Furniture'];

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get('http://localhost:9090/api/books');
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
      setError('Failed to fetch books');
    }
  };

  const handleCreateBook = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:9090/api/books', { title, description, city, year, category });
      if (response.data && response.data.title && response.data.description && response.data.year) {
        alert(`Book created: ${response.data.title} by ${response.data.description}, ${response.data.year} year`);
        setTitle('');
        setDescription('');
        setCity('');
        setYear('');
        setCategory('Transport');
        fetchBooks();
      } else {
        setError('Failed to create book');
      }
    } catch (error) {
      console.error('Error creating book:', error);
      setError('Failed to create book');
    }
  };

  const handleDeleteBook = async (id) => {
    try {
      await axios.delete(`http://localhost:9090/api/books/${id}`);
      setBooks(books.filter(book => book.id !== id)); // Удаление книги из состояния books
      setFilteredBooks(filteredBooks.filter(book => book.id !== id)); // Удаление книги из отфильтрованных книг
    } catch (error) {
      console.error('Error deleting book:', error);
      setError('Failed to delete book');
    }
  };

  const handleEditBook = (book) => {
    setIsEditing(true);
    setCurrentBook(book);
    setTitle(book.title);
    setDescription(book.description);
    setCity(book.city);
    setYear(book.year);
    setCategory(book.category);
  };

  const handleUpdateBook = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.put(`http://localhost:9090/api/books/${currentBook.id}`, { title, description, city, year, category });
      if (response.data && response.data.title && response.data.description && response.data.year) {
        alert(`Book updated: ${response.data.title} by ${response.data.description}, ${response.data.year} year`);
        setTitle('');
        setDescription('');
        setCity('');
        setYear('');
        setCategory('Transport');
        setIsEditing(false);
        setCurrentBook(null);
        fetchBooks();
      } else {
        setError('Failed to update book');
      }
    } catch (error) {
      console.error('Error updating book:', error);
      setError('Failed to update book');
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setCurrentBook(null);
    setTitle('');
    setDescription('');
    setCity('');
    setCategory('Transport');
  };

  // Функция для фильтрации книг по категории
  const handleFilterBooks = (selectedCategory) => {
    if (selectedCategory === 'All') {
      setFilteredBooks(books);
    } else {
      const filtered = books.filter((book) => book.category === selectedCategory);
      setFilteredBooks(filtered);
    }
  };

  // Функция для поиска книг по заголовку
  const handleSearchBooks = () => {
    if (searchTerm.trim() === '') {
      setFilteredBooks(books); // Если поисковый запрос пустой, показываем все книги
    } else {
      const filtered = books.filter((book) =>
        book.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredBooks(filtered);
    }
  };

  return (
    <div>
      <h1>Book Management</h1>
      <form onSubmit={isEditing ? handleUpdateBook : handleCreateBook}>
        <label htmlFor="title">Title:</label>
        <input type="text" id="title" value={title} onChange={(event) => setTitle(event.target.value)} /><br /><br />
        <label htmlFor="description">Description:</label>
        <input type="text" id="description" value={description} onChange={(event) => setDescription(event.target.value)} /><br /><br />
        <label htmlFor="city">City:</label>
        <input type="text" id="city" value={city} onChange={(event) => setCity(event.target.value)} /><br /><br />
        <label htmlFor="year">Pri:</label>
        <input type="number" id="year" value={year} onChange={(event) => setYear(event.target.value)} /><br /><br />
        <label htmlFor="category">Category:</label>
        <select id="category" value={category} onChange={(event) => setCategory(event.target.value)}>
          {categories.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select><br /><br />
        <button type="submit">{isEditing ? 'Update Book' : 'Create Book'}</button>
        {isEditing && <button type="button" onClick={handleCancelEdit}>Cancel</button>}
      </form>
      <div>
        <h2>Filter Books</h2>
        <button onClick={() => handleFilterBooks('All')}>Show All</button>
        {categories.map((cat) => (
          <button key={cat} onClick={() => handleFilterBooks(cat)}>Filter {cat}</button>
        ))}
      </div>
      <div>
        <h2>Search Books</h2>
        <input type="text" placeholder="Search by title..." value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} />
        <button onClick={handleSearchBooks}>Search</button>
      </div>
      <h2>Books</h2>
      <ul>
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <div key={book.id} >
              <li >
                  {book.title && book.description && book.year && book.city ? `${book.title} Description:${book.description}, Price: ${book.year} , City: ${book.city}, Category: ${book.category}` : 'Invalid book data'}
                <button onClick={() => handleEditBook(book)}>Edit</button>
                <button onClick={() => handleDeleteBook(book.id)}>Delete</button>
              </li>
            </div>
          ))
        ) : (
          <p>No books found.</p>
        )}
      </ul>
      {error && <p>{error}</p>}
    </div>
  );
}

export default App;
